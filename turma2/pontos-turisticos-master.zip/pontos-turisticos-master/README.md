# pontos-turisticos
Código fonte do curso de Django Rest APIs

Repositorio do curso de DRF em Portugues
https://www.udemy.com/instructor/course/1631400

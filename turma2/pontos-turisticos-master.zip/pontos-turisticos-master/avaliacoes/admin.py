from django.contrib import admin
from .models import Avaliacao


admin.site.register(Avaliacao)

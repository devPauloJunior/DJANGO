from django.contrib import admin
from .models import Endereco


admin.site.register(Endereco)

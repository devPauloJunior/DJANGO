from django.apps import AppConfig


class ComentariosConfig(AppConfig):
    name = 'comentarios'

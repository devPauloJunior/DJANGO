from django.contrib import admin
from .models import Comentario


admin.site.register(Comentario)
